import boto3
import json

def lambda_handler(event, context):   
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('MyTable')
    Id = event['ID']
    response = table.get_item(
        Key={
            'ID': Id
            }
    )
    item = response['Item']
    print(item)
    return(item)
    
   
    
