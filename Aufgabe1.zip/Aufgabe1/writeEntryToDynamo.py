import json
import boto3

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    client = boto3.client('lambda')
    table = dynamodb.Table('MyTable')
    Id = event['key1']
    value = event['key2']
    try:
        response = table.put_item(
        Item={
            'ID': Id,
            'FirstName': value
        }
        )
        
        logMsg = {
            'log1' : value + " has been added with Id " + str(Id)
        }
        res = client.invoke(
            FunctionName = "arn:aws:lambda:eu-central-1:384647844144:function:Logger",
            InvocationType = 'RequestResponse',
            Payload = json.dumps(logMsg)
        )
        print(res['Payload'].read())
    except ValueError:
        print("Mistake")
        

    return response
