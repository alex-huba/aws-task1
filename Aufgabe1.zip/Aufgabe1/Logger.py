import json

def lambda_handler(event, context):
    print(event["log1"])
    print("Success")
    res = event["log1"]
    return res
    
