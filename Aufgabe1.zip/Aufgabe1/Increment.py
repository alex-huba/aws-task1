import json
import boto3


client = boto3.client('lambda')
def lambda_handler(event, context):
    key1 = event["key1"]
    
    key1 = int(key1)
    
    if key1 < 10:
        print(key1)
        
        logMsg = {
            'log' : key1
        }
        res = client.invoke(
            FunctionName = "arn:aws:lambda:eu-central-1:384647844144:function:Logger",
            InvocationType = 'RequestResponse',
            Payload = json.dumps(logMsg)
        )
        
        inputParams={
            'key1' : key1 +2
        }
        response = client.invoke(
            FunctionName = "arn:aws:lambda:eu-central-1:384647844144:function:Decrement",
            InvocationType = 'Event',
            Payload = json.dumps(inputParams)
        )
    else:
        print("DONE")
    
    
    